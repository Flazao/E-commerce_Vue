<template>
    <footer class="bg-black p-2 bottom-0 left-0 w-full m-0 text-white text-center">
        <div class="text-bold p-2 text-md">
            <h1>Feito por Gabriel Flazao e José Fujii</h1>
            <h2>Todos os direitos reservados &copy;</h2>
        </div>
    </footer>
</template>