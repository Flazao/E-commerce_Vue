<template>
    <div class="bg-gray-100">
        <h1>ola mundo</h1>
    </div>
</template>